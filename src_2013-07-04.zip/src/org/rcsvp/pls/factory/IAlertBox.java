package org.rcsvp.pls.factory;

/**
 * IAlertBox interface は、IControlCenter で使用する、各種機器の警告情報を保持するためのモデルです。
 * 
 * @author Rcsvp.org
 * @date Jul 3, 2013
 * 
 */
public interface IAlertBox {

}
