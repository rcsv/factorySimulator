/**
 * このパッケージには、ProductionLine シミュレータで使用する共通部品が配置されています。
 * 
 * @author Rcsvp.org
 * @date   Jul 3, 2013
 * 
 */
package org.rcsvp.pls.util;